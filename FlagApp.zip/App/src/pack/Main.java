package pack;

import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {

		Scanner scan = new Scanner(System.in);
/*
		System.out.println("Options: Horizontal / Vertical");
		System.out.print("Pick stripe direction");
		String flagOrientation = scan.nextLine();

		System.out.println("Options: Yes / No: ");
		System.out.print("Do you want a coat of arms on your flag?");
		String plainFlag = scan.nextLine();
	*/	
	
		FlagBuilder fb = new FlagBuilder();
		Flag fg = fb.flagBuilder();
		fg.print();
		
	}
}

// width, height, symbol size, symbol color, symbol background color, symbol
// image, vertical alignment,
// horizontal alignment, flag colors
// Flag flag0 = new HorizontalFlag();
//Flag flag1 = new VerticalFlag(21, 36, 16, "white", "none", "dolphin", "middle", "center", "red", "green", "blue");
//Flag flag2 = new HorizontalFlag(30, 20, 15, "white", "red", "eagle", 20./52., 21. / 56., "red", "blue", "white");
//Flag flag3 = new HorizontalFlag(90, 60, 45, "yellow", "red", "eagle", 20./52., 21. / 56., "red", "blue", "white");

//Flag flag4 = new HorizontalFlag(temp);

//flag0.print();
//flag1.print();
//flag2.print();
//flag3.print();
//flag4.print();
