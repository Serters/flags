package pack;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class CoatOfArms {
	private int size;
	private String foregroundColor;
	private String backgroundColor;
	private String[] array;

	public CoatOfArms() throws IOException{
		this.size = 24;
		this.foregroundColor = Colors.getForeground("white");
		this.backgroundColor = Colors.getBackground("none");
		this.array = bufferedImageToStringArray("dolphin");
	}

	public CoatOfArms(int size, String foregroundColor, String backgroundColor, String imageName) throws IOException{
		this.size = size;
		this.foregroundColor = Colors.getForeground(foregroundColor);
		this.backgroundColor = Colors.getBackground(backgroundColor);
		this.array = bufferedImageToStringArray(imageName);
	}

	private String[] bufferedImageToStringArray(String name) throws IOException{
		BufferedImage image = resizeBufferedImage(name, this.size);
		String[] array = new String[image.getHeight()];
		for(int y = 0; y < image.getHeight(); y++){
			String row = "";
			for(int x = 0; x < image.getWidth(); x++){
				int pixel = image.getRGB(x, y);
				int a = pixel >> 24 & 0xFF;
				String s = a == 255 ? "██" : "  ";
				row += s;
			}
			array[y] = row;
		}
		return array;
	}

	private static BufferedImage resizeBufferedImage(String name, int size) throws IOException{
		BufferedImage image = ImageIO.read(new File(name + ".png"));
		Image resultingImage = image.getScaledInstance(size * image.getWidth() / image.getHeight(), size, Image.SCALE_DEFAULT);
		BufferedImage outputImage = new BufferedImage(size * image.getWidth() / image.getHeight(), size, BufferedImage.TYPE_INT_ARGB);
		outputImage.getGraphics().drawImage(resultingImage, 0, 0, null);
		return outputImage;
	}

	public int getSize(){ return this.size; }

	public int getWidth(){ return this.array[0].length(); }

	public String getForegroundColor(){ return this.foregroundColor; }

	public String getBackgroundColor(){ return this.backgroundColor; }

	public String[] getArray(){ return this.array; }
}