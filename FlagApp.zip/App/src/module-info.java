/**
 * 
 */
/**
 * @author stras
 *
 */
module App {
	
	requires java.desktop;
	
}